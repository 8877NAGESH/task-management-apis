package com.nagesh.Management.TaskManagementAPI;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TaskManagementApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
